// ParallelskeletonProgram.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


//#include "stdafx.h"
#include <iostream>
#include <omp.h>
#include <stdio.h>
#include <iterator>
#include <type_traits>
#include <vector>
#include <mpi.h> //To use MPI
#include <complex.h> //to use complex numbers
#include <math.h>	//for cos() and sin()
#include "timer.h" //to use timer

#define PI 3.14159265// it's constant that equal 3.14 and kepps going on and on *//
//#define bigN 16384 //Problem Size
#define howmanytimesavg 3 //How many times do I wanna run for the AVG?

#define N 8 //*constant or micro substitution. It can use any basic data type *//
using namespace std;//*differentiate similar functions, classes, variables etc. with the same name available in different libraries. Using namespace, you can define the context in which names are defined. In essence, a namespace defines a scope.*//

void printVar(int a[], int b, int c, int d, int m) {
	cout << "b = " << b << ", c = " << c << ", d = " << d << " m = " << m << endl;
	cout << "a = ";
	for (int i = 0; i < N; i++)
		cout << a[i] << ", ";
	cout << endl;
}

int main()
{
	
	int i;
	int a[N];
	int b = 0, c = 0, d = 0, m = 0;
	cout << "Before par. for" << endl;
	printVar(a, b, c, d, m);
	// private: another environment (like a function)
	// firstprivate: initialized with the value that it had before the parallel region
	// lastprivate: private version of whichever thread executes the final iteration
	// shared: all threads within a team access the same storage area for shared variables
	// default(none) forces a programmer to explicitly specify the data-sharing attributes of all variables
#pragma omp parallel for default(none) private(i,b) firstprivate(c) lastprivate(d) shared(m,a) schedule(static, 3) num_threads(4)
	for (i = 0; i < N; i++) {
		// b and d must be initialized
		b = 100;
		d = 10;
		printf("Thread %d, iteration %d: b = %d, c = %d, d = %d, m = %d\n", omp_get_thread_num(), i, b, c, d, m);
		a[i] = omp_get_thread_num();
		b = omp_get_thread_num();
		c = omp_get_thread_num();
		d = omp_get_thread_num();
		m = omp_get_thread_num();
	}
	cout << "After par. for" << endl;
	printVar(a, b, c, d, m);
	getchar();
	return 0;

	int my_rank, comm_sz;
	MPI_Init(NULL, NULL); //start MPI
	MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);   ///how many processes are we using?
	MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);   //which process is this?
	double start, finish;
	double avgtime = 0;
	FILE *outfile;
	int h;
	if (my_rank == 0) //if process 0 open outfile
	{
		outfile = fopen("ParallelVersionOutput.txt", "w"); //open from current directory
	}
	for (h = 0; h < howmanytimesavg; h++) //loop to run multiple times for AVG time.
	{
		if (my_rank == 0) //If it's process 0 starts timer
		{
			start = MPI_Wtime();
		}
		int i, k, n, j; //Basic loop variables

		double complex evenpart[(bigN / comm_sz / 2)]; //array to save the data for EVENHALF
		double complex oddpart[(bigN / comm_sz / 2)]; //array to save the data for ODDHALF
		double complex evenpartmaster[(bigN / comm_sz / 2) * comm_sz]; //array to save the data for EVENHALF
		double complex oddpartmaster[(bigN / comm_sz / 2) * comm_sz]; //array to save the data for ODDHALF
		double storeKsumreal[bigN]; //store the K real variable so we can abuse symmerty
		double storeKsumimag[bigN]; //store the K imaginary variable so we can abuse symmerty

		double subtable[(bigN / comm_sz)][3]; //Each process owns a subtable from the table below 

		double table[bigN][3] = //TABLE of numbers to use
		{
		 0,3.6,2.6, //n, Real,Imaginary CREATES TABLE
		 1,2.9,6.3,
		 2,5.6,4.0,
		 3,4.8,9.1,
		 4,3.3,0.4,
		 5,5.9,4.8,
		 6,5.0,2.6,
		 7,4.3,4.1,
		};
		if (bigN > 8)  //Everything after row 8 is all 0's
		{
			for (i = 8; i < bigN; i++)
			{
				table[i][0] = i;
				for (j = 1; j < 3; j++)
				{
					table[i][j] = 0.0; //set to 0.0
				}
			}
		}
		int sendandrecvct = (bigN / comm_sz) * 3; //how much to send and recieve??
		MPI_Scatter(table, sendandrecvct, MPI_DOUBLE, subtable, sendandrecvct, MPI_DOUBLE, 0, MPI_COMM_WORLD); //scatter the table to subtables
		for (k = 0; k < bigN / 2; k++) //K coeffiencet Loop 
		{
			/* Variables used for the computation */
			double sumrealeven = 0.0; //sum of real numbers for even
			double sumimageven = 0.0; //sum of imaginary numbers for even
			double sumrealodd = 0.0; //sum of real numbers for odd
			double sumimagodd = 0.0; //sum of imaginary numbers for odd

			for (i = 0; i < (bigN / comm_sz) / 2; i++) //Sigma loop EVEN and ODD
			{
				double factoreven, factorodd = 0.0;
				int shiftevenonnonzeroP = my_rank * subtable[2 * i][0]; //used to shift index numbers for correct results for EVEN.
				int shiftoddonnonzeroP = my_rank * subtable[2 * i + 1][0]; //used to shift index numbers for correct results for ODD.

				/* -------- EVEN PART -------- */
				double realeven = subtable[2 * i][1]; //Access table for real number at spot 2i
				double complex imaginaryeven = subtable[2 * i][2]; //Access table for imaginary number at spot 2i
				double complex componeeven = (realeven + imaginaryeven * I); //Create the first component from table
				if (my_rank == 0) //if proc 0, dont use shiftevenonnonzeroP
				{
					factoreven = ((2 * PI)*((2 * i)*k)) / bigN; //Calculates the even factor for Cos() and Sin()										
								//   *********Reduces computational time*********
				}
				else //use shiftevenonnonzeroP
				{
					factoreven = ((2 * PI)*((shiftevenonnonzeroP)*k)) / bigN; //Calculates the even factor for Cos() and Sin()										
								//   *********Reduces computational time*********
				}
				double complex comptwoeven = (cos(factoreven) - (sin(factoreven)*I)); //Create the second component

				evenpart[i] = (componeeven * comptwoeven); //store in the evenpart array

				/* -------- ODD PART -------- */
				double realodd = subtable[2 * i + 1][1]; //Access table for real number at spot 2i+1
				double complex imaginaryodd = subtable[2 * i + 1][2]; //Access table for imaginary number at spot 2i+1
				double complex componeodd = (realodd + imaginaryodd * I); //Create the first component from table
				if (my_rank == 0)//if proc 0, dont use shiftoddonnonzeroP
				{
					factorodd = ((2 * PI)*((2 * i + 1)*k)) / bigN;//Calculates the odd factor for Cos() and Sin()										
								// *********Reduces computational time*********	
				}
				else //use shiftoddonnonzeroP
				{
					factorodd = ((2 * PI)*((shiftoddonnonzeroP)*k)) / bigN;//Calculates the odd factor for Cos() and Sin()										
								// *********Reduces computational time*********
				}

				double complex comptwoodd = (cos(factorodd) - (sin(factorodd)*I));//Create the second component

				oddpart[i] = (componeodd * comptwoodd); //store in the oddpart array

			}
			/*Process ZERO gathers the even and odd part arrays and creates a evenpartmaster and oddpartmaster array*/
			MPI_Gather(evenpart, (bigN / comm_sz / 2), MPI_DOUBLE_COMPLEX, evenpartmaster, (bigN / comm_sz / 2), MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD);
			MPI_Gather(oddpart, (bigN / comm_sz / 2), MPI_DOUBLE_COMPLEX, oddpartmaster, (bigN / comm_sz / 2), MPI_DOUBLE_COMPLEX, 0, MPI_COMM_WORLD);

			if (my_rank == 0)
			{
				for (i = 0; i < (bigN / comm_sz / 2) * comm_sz; i++) //loop to sum the EVEN and ODD parts
				{
					sumrealeven += creal(evenpartmaster[i]); //sums the realpart of the even half
					sumimageven += cimag(evenpartmaster[i]); //sums the imaginarypart of the even half
					sumrealodd += creal(oddpartmaster[i]); //sums the realpart of the odd half
					sumimagodd += cimag(oddpartmaster[i]); //sums the imaginary part of the odd half
				}
				storeKsumreal[k] = sumrealeven + sumrealodd; //add the calculated reals from even and odd
				storeKsumimag[k] = sumimageven + sumimagodd; //add the calculated imaginary from even and odd
				storeKsumreal[k + bigN / 2] = sumrealeven - sumrealodd; //ABUSE symmetry Xkreal + N/2 = Evenk - OddK
				storeKsumimag[k + bigN / 2] = sumimageven - sumimagodd; //ABUSE symmetry Xkimag + N/2 = Evenk - OddK
				if (k <= 10) //Do the first 10 K's
				{
					if (k == 0)
					{
						fprintf(outfile, " \n\n TOTAL PROCESSED SAMPLES : %d\n", bigN);
					}
					fprintf(outfile, "================================\n");
					fprintf(outfile, "XR[%d]: %.4f XI[%d]: %.4f \n", k, storeKsumreal[k], k, storeKsumimag[k]);
					fprintf(outfile, "================================\n");
				}
			}
		}
		if (my_rank == 0)
		{
			GET_TIME(finish); //stop timer
			double timeElapsed = finish - start; //Time for that iteration
			avgtime = avgtime + timeElapsed; //AVG the time 
			fprintf(outfile, "Time Elaspsed on Iteration %d: %f Seconds\n", (h + 1), timeElapsed);
		}
	}
	if (my_rank == 0)
	{
		avgtime = avgtime / howmanytimesavg; //get avg time
		fprintf(outfile, "\nAverage Time Elaspsed: %f Seconds", avgtime);
		fclose(outfile); //CLOSE file ONLY proc 0 can.
	}
	MPI_Barrier(MPI_COMM_WORLD); //wait to all proccesses to catch up before finalize
	MPI_Finalize(); //End MPI
	return 0;
	constexpr auto pi() { return atan(1) * 4; }

	//Folowing is for SFINAE    
	template <typename T>
	struct extractType;

	template <template <typename ...> class C, typename D>
	struct extractType<C<D>> { using subType = D; };

	// Cooley�Tukey Fast Fourier Transform algorithm
	// Recursive Divide and Conquer implementation
	// Higher memory requirements and redundancy although more intuitive
	

		typename enable_if<is_same<value_type,
		complex<typename extractType<value_type>::subType>>::value,
		void>::type // Only accepts std::complex numbers containers 
		FFT(InputIt begin, InputIt end)
	{
		typename iterator_traits<InputIt>::difference_type N = distance(begin, end);//*. iterative algorithm by simply subdividing each resulting subproblem iteratively
		// The input data xo, xl, , x, +l are said to be in �natura1 Order� if XI and XI + , are stored in
			//consecutive locations in o for all 0 < l < N - 2. Similarly, the output data Xo, Xl, , xN_ 1 are said

		if (N < 2) return;
		else {
			// divide
			stable_partition(begin, end, [&begin](auto& a) {//*iterator function ,begin return iterator to the beginnging of container 
				//end return the last element of the container *//
				return distance(&*begin, &a) % 2 == 0; // pair indexes on the first half and odd on the last
			});

			//conquer
			FFT(begin, begin + N / 2);   // recurse even items
			FFT(begin + N / 2, end);   // recurse odd  items

			//combine
			for (decltype(N) k = 0; k < N / 2; ++k) {
				value_type even = *(begin + k);
				value_type odd = *(begin + k + N / 2);
				value_type w = exp(value_type(0, -2.*pi()*k / N)) * odd;

				*(begin + k) = even + w;
				*(begin + k + N / 2) = even - w;
			}
		}
	}



	// Inverse FFT
	template<typename InputIt,//*generic programming by means of special constructs called templates *//
		typename value_type = typename iterator_traits<InputIt>::value_type>
		typename enable_if<is_same<value_type,
		complex<typename extractType<value_type>::subType>>::value,
		void>::type
		IFFT(InputIt begin, InputIt end)
	{
		typename iterator_traits<InputIt>::difference_type N = distance(begin, end);//*so the iterator it's an object that enable traversal of some containers in some order for reading or writing 

		if (N < 2) return;
		else {
			// divide
			stable_partition(begin, end, [&begin](auto& a) {
				a = conj(a); // use the conjugate value
				return distance(&*begin, &a) % 2 == 0; // pair indexes on the first half and odd on the last
			});

			//conquer
			FFT(begin, begin + N / 2);   // recurse even items on normal FFT
			FFT(begin + N / 2, end);   // recurse odd  items on normal FFT

			//combine
			for (decltype(N) k = 0; k < N / 2; ++k) {
				value_type even = *(begin + k);
				value_type odd = *(begin + k + N / 2);
				value_type w = exp(value_type(0, -2.*pi()*k / N)) * odd;

				*(begin + k) = conj(even + w); //conjugate again and scale 
				*(begin + k) /= N;
				*(begin + k + N / 2) = conj(even - w);
				*(begin + k + N / 2) /= N;



				
				 //**multiplying 2 polynomials
				{
					/*Input:  A[] = {5, 0, 10, 6}
						B[] = {1, 2, 4}
					  Output: prod[] = {5, 10, 30, 26, 52, 24} */

					vector<complex<double>> A{ 5, 0, 10, 6 };//*it's a container that implment dynamic sized array support random access 
					vector<complex<double>> B{ 1, 2, 4 };
					size_t result_size = A.size() + B.size() - 1; // resulting degree after mult

					// print originals
					cout << "Input:  A[] = {";
					for (auto& n : A) cout << n.real() << ", ";
					cout << "\b\b}\n";
					cout << "Input:  B[] = {";
					for (auto& n : B) cout << n.real() << ", ";
					cout << "\b\b}\n";


					// pad inputs with zeroes (need to be even)
					size_t algo_size = A.size() + B.size();
					if (algo_size % 2 == 1) ++algo_size;
					A.resize(algo_size, complex<double>(0));
					B.resize(algo_size, complex<double>(0));


					vector<complex<double>> result(algo_size, 0);

					// FFT
					FFT(begin(A), end(A));
					FFT(begin(B), end(B));

					// Multiply
					for (size_t i = 0; i < result.size(); ++i) {
						result[i] = A[i] * B[i]; // O(n)
					}

					// Inverse FFT
					IFFT(begin(result), end(result));

					// Remove padding zeroes
					result.resize(result_size);

					cout << "Output: prod[] = {";
					for (auto& n : result) cout << static_cast<int>(n.real()) << ", ";
					cout << "\b\b}\n";

					return 0;


					void fft_rec(std::complex<double> *x, int N) {
						// Check if it is splitted enough
						if (N <= 1) {
							return;
						}

						// Split even and odd
						std::complex<double> odd[N / 2];
						std::complex<double> even[N / 2];
						for (int i = 0; i < N / 2; i++) {
							even[i] = x[i * 2];
							odd[i] = x[i * 2 + 1];
						}

						// Split on tasks
						fft_rec(even, N / 2);
						fft_rec(odd, N / 2);


						// Calculate DFT
					//*	for (int k = 0; k < N / 2; k++) {//*
							//std::complex<double> t = exp(std::complex<double>(0, -2 * M_PI * k / N)) * odd[k];*//
							//x[k] = even[k] + t;*//
							//x[N / 2 + k] = even[k] - t;*//
						}
					}

				}










}









}


